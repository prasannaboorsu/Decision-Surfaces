import streamlit as st
import pandas as pd
from mlxtend.plotting import plot_decision_regions
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import numpy as np

# Load datasets
ushape= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\1.ushape.csv",header=None,names=["f1","f2","cv"])
concentri1= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\2.concerticcir1.csv",header=None,names=["f1","f2","cv"])
concentri2= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\3.concertriccir2.csv",header=None,names=["f1","f2","cv"])
linearshape= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\4.linearsep.csv",header=None,names=["f1","f2","cv"])
outlier= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\5.outlier.csv",header=None,names=["f1","f2","cv"])
overlap= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\6.overlap.csv",header=None,names=["f1","f2","cv"])
xor= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\7.xor.csv",header=None,names=["f1","f2","cv"])
twospirals= pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\8.twospirals.csv",header=None,names=["f1","f2","cv"])
random =pd.read_csv(r"C:\Users\arsha\Downloads\Multiple CSV\Multiple CSV\9.random.csv",header=None,names=["f1","f2","cv"])

# Streamlit app layout
st.set_page_config(
    page_title="Decision Surfaces Explorer",
    page_icon=":chart_with_upwards_trend:",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.title("Decision Surfaces Explorer")

with st.sidebar:
    st.title("Explorezone")
    radio_button = st.radio("Datasets", ["ushape","concentri1","concentri2",'linearshape','outlier','overlap','xor','twospirals','random'])
    k = st.slider("K value", min_value=1, max_value=15)
    radio_button2 = st.radio("Decision Surfaces", ['Single', 'Multiple'])

# Display selected dataset
selected_dataset = None
if radio_button == 'ushape':
    selected_dataset = ushape
elif radio_button == 'concentri1':
    selected_dataset = concentri1
elif radio_button == 'concentri2':
    selected_dataset = concentri2
elif radio_button == 'linearshape':
    selected_dataset = linearshape
elif radio_button == 'outlier':
    selected_dataset = outlier
elif radio_button == 'overlap':
    selected_dataset = overlap
elif radio_button == 'xor':
    selected_dataset = xor
elif radio_button == 'twospirals':
    selected_dataset = twospirals
elif radio_button == 'random':
    selected_dataset = random

st.write(f"Displaying {radio_button} dataset")
st.scatter_chart(data=selected_dataset, x='f1', y='f2', use_container_width=True)

fv = selected_dataset.iloc[:, :2]
cv = selected_dataset.iloc[:, -1]
std = StandardScaler()
p_fv = std.fit_transform(fv)

if radio_button2 == 'Single':
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(p_fv, cv.astype(int))
    fig, ax = plt.subplots()
    plot_decision_regions(X=p_fv, y=cv.astype(int).values, clf=knn, ax=ax, legend=2)
    ax.set_xlim(p_fv[:, 0].min() - 1, p_fv[:, 0].max() + 1)
    ax.set_ylim(p_fv[:, 1].min() - 1, p_fv[:, 1].max() + 1)
    ax.set_title(f'Decision Surface (K={k})')
    st.pyplot(fig)

elif radio_button2 == 'Multiple':
    fig, axes = plt.subplots(3, 2, figsize=(15, 15))

    for i, ax in zip(range(1, k, 2), axes.flatten()):
        knn = KNeighborsClassifier(n_neighbors=i)
        knn.fit(fv.values, cv.astype(int))
        plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax, legend=2)
        ax.set_xlim(fv.iloc[:, 0].min() - 1, fv.iloc[:, 0].max() + 1)
        ax.set_ylim(fv.iloc[:, 1].min() - 1, fv.iloc[:, 1].max() + 1)
        ax.set_title(f'Decision Surface (K={i})')
    plt.tight_layout()
    st.pyplot(fig)

x_train, x_test, y_train, y_test = train_test_split(fv, cv, test_size=0.2, random_state=1, stratify=cv)
std = StandardScaler()
px_train = std.fit_transform(x_train)
px_test = std.transform(x_test)

train_error = []
test_error = []
error = []
for i in range(1, k, 2):
    knn = KNeighborsClassifier(n_neighbors=i)

